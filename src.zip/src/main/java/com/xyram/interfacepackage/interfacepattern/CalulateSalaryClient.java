package com.xyram.interfacepackage.interfacepattern;

import java.math.BigDecimal;

public class CalulateSalaryClient {
    public void calculateSalary(Person person){
        person.calculateSalary();
    }
}
