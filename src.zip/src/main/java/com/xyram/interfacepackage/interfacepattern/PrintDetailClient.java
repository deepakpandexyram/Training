package com.xyram.interfacepackage.interfacepattern;

import java.math.BigDecimal;

public class PrintDetailClient {
    public void printdetail(Person person){
        person.printDetail();
    }
}
