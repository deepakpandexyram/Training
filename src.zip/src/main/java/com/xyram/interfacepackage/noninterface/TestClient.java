package com.xyram.interfacepackage.noninterface;

public class TestClient {
    public static void main(String[] args){
        CalulateSalaryClient calulateSalaryClient = new CalulateSalaryClient();
        calulateSalaryClient.calSalary("SalesAssociate");
        PrintDetailClient printDetailClient = new PrintDetailClient();
        printDetailClient.printdetail("Developer");
    }
}
